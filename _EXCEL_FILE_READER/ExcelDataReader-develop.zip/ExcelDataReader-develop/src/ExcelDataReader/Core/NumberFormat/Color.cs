﻿namespace ExcelDataReader.Core.NumberFormat
{
    internal class Color
    {
        public string Value { get; set; }
    }
}
