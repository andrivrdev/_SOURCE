using System.Collections.Generic;

namespace ExcelDataReader.Core.OpenXmlFormat
{
    /// <summary>
    /// Shared string table
    /// </summary>
    internal class XlsxSST : List<string>
    {
    }
}
